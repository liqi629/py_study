create definer = root@`%` trigger customer_create_date
    before INSERT
    on customer
    for each row
    SET NEW.create_date = NOW();

